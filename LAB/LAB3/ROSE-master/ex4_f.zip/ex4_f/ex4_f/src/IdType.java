
public class IdType {
    public static int BOOLEAN = 1;
    public static int INTEGER = 2;
    public static int ARRAY = 3;
    public static int RECORD = 4;
    public static int PROCEDURE = 5;
};
