import java.io.*;
import java.util.Random;

/**
 * 该类用于生成随机的算术表达式，并将它们保存为文件。
 * 表达式包含随机生成的数字和操作符（加号或减号）。
 */
public class GenerateExpressions {

    /**
     * 主方法，用于启动表达式生成过程。
     * @param args 命令行参数，不使用
     * @throws IOException 如果发生输入输出异常
     */
    public static void main(String[] args) throws IOException {
        File directory = new File("./testcases");
        if (!directory.exists()) {
            directory.mkdirs(); // 创建存放测试用例的目录
        }

        int maxN = 10000; // 表达式的最大长度
        int trials = 2; // 每个长度生成的表达式数量
        Random rand = new Random(); // 随机数
        int fileIndex = 1; // 文件编号

        // 循环生成表达式文件
        for (int N = 1; N <= maxN; N += 10) {
            for (int trial = 0; trial < trials; trial++) {
                String fileName = String.format("tc-%03d.infix", fileIndex);
                File file = new File(directory, fileName);
                try (PrintWriter writer = new PrintWriter(file)) {
                    String expression = generateExpression(N, rand);
                    System.out.println(expression);
                    writer.println(expression);
                }
                fileIndex++;
            }
        }
    }

    /**
     * 根据指定长度生成一个随机算术表达式。
     * 表达式由随机数字和操作符（'+'或'-'）组成。
     * @param N 表达式的长度
     * @param rand 随机数生成器，用于生成数字和选择操作符
     * @return 生成的算术表达式字符串
     */
    static String generateExpression(int N, Random rand) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < N; i++) {
            sb.append(rand.nextInt(10));  // 随机生成一个数字
            if (i < N - 1) {  // 在数字之间随机添加操作符（如果不是最后一个数字）
                sb.append(rand.nextBoolean() ? '+' : '-');
            }
        }
        return sb.toString();
    }
}
