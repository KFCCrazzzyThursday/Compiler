import java.io.*;

/**
 * 解析器类，用于处理算术表达式，并转换为后缀记法。
 * 它提供详细的错误报告，通过区分词法错误和语法错误。
 */
class Parser {
    static int lookahead;
    static int position = 1; // track position
    static StringBuilder errors = new StringBuilder();
    static boolean expectingOperator = false; // expect for a number at first

    /**
     * 构造函数从System.in读取第一个字符。
     * @throws IOException 如果输入错误发生。
     */
    public Parser() throws IOException {
        lookahead = System.in.read();
    }

    /**
     * 开始解析表达式。
     * @throws IOException 如果输入错误发生。
     */
    void expr() throws IOException {
        while (lookahead != -1 && lookahead != '\n' && lookahead != '\r') {
            if (Character.isWhitespace((char) lookahead)) {
                skipWhitespace();
            } else if (Character.isDigit((char) lookahead)) {
                if (expectingOperator) {
                    reportError("Missing operator between numbers", "Syntax Error");
                    expectingOperator = false; // Reset expectation state
                }
                term();
                expectingOperator = true; // Expecting an operator after a number
            } else if (lookahead == '+' || lookahead == '-') {
                if (!expectingOperator) {
                    reportError("Missing operand before operator", "Syntax Error");
                }
                rest();
                expectingOperator = false; // Expecting a number after an operator
            } else {
                reportError("Illegal character", "Lexical Error");
                recover();
            }
        }
    }


    /**
     * 跳过空格，并报告空格为错误。
     * @throws IOException 如果输入错误发生。
     */
    void skipWhitespace() throws IOException {
        if (Character.isWhitespace((char) lookahead)) { // blank found
            reportError("blank is not allowed", "lexical error");
        }
        while (Character.isWhitespace((char) lookahead)) {
            position++;
            lookahead = System.in.read();
        }
    }


    /**
     * 匹配当前字符和期望字符。
     * @param t 期望的字符。
     * @throws IOException 如果输入错误发生。
     */
    void match(int t) throws IOException {
        if (lookahead == t) {
            position++;
            lookahead = System.in.read();
        } else {
            reportError("expect '" + (char)t + "' while find '" + (char)lookahead + "'", "syntax error");
            recover();
        }
    }

    /**
     * 处理运算符后续的数字。
     * @throws IOException 如果输入错误发生。
     */
    void rest() throws IOException {
        int operator = lookahead;
        match(lookahead);
        System.out.write(operator);
    }

    /**
     * 处理数字。
     * @throws IOException 如果输入错误发生。
     */
    void term() throws IOException {
        System.out.write((char) lookahead);
        match(lookahead);
    }

    /**
     * 从错误中恢复，跳过当前字符，直到遇到下一个可能是合法输入的字符。
     * @throws IOException 如果输入错误发生。
     */
    void recover() throws IOException {
        while (lookahead != -1 && !Character.isDigit((char) lookahead) && lookahead != '+' && lookahead != '-' && !Character.isWhitespace((char) lookahead)) {
            lookahead = System.in.read();
            position++;
        }
    }

    /**
     * 报告错误。
     * @param msg 错误信息。
     * @param errorType 错误类型（词法或语法错误）。
     */
    void reportError(String msg, String errorType) {
        errors.append("position ").append(position).append(": ").append(msg).append(" [").append(errorType).append("]\n");
    }
}

/**
 * 主类用于执行解析器。
 */
public class Postfix {
    public static void main(String[] args) throws IOException {
        System.out.println("Input an infix expression and output its postfix notation:");
        Parser parser = new Parser();
        parser.expr();
        System.out.println("\nEnd of program.");
        if (parser.errors.length() > 0) {
            System.err.println("Error found:\n" + parser.errors.toString());
        }
    }
}
